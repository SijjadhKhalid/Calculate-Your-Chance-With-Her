﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.lblAttractive = New System.Windows.Forms.Label()
        Me.txtAy = New System.Windows.Forms.TextBox()
        Me.txtAh = New System.Windows.Forms.TextBox()
        Me.lblAttractive1 = New System.Windows.Forms.Label()
        Me.txtEy = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtW = New System.Windows.Forms.TextBox()
        Me.lblConversation = New System.Windows.Forms.Label()
        Me.txtR = New System.Windows.Forms.TextBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtK = New System.Windows.Forms.TextBox()
        Me.txtSh = New System.Windows.Forms.TextBox()
        Me.txtSy = New System.Windows.Forms.TextBox()
        Me.txtCminus = New System.Windows.Forms.TextBox()
        Me.txtCplus = New System.Windows.Forms.TextBox()
        Me.txtG = New System.Windows.Forms.TextBox()
        Me.txtEh = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(854, 304)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmit.TabIndex = 0
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'lblAttractive
        '
        Me.lblAttractive.AutoSize = True
        Me.lblAttractive.Location = New System.Drawing.Point(9, 17)
        Me.lblAttractive.Name = "lblAttractive"
        Me.lblAttractive.Size = New System.Drawing.Size(154, 13)
        Me.lblAttractive.TabIndex = 1
        Me.lblAttractive.Text = "How Attractive Are You? (1-10)"
        '
        'txtAy
        '
        Me.txtAy.Location = New System.Drawing.Point(372, 14)
        Me.txtAy.Name = "txtAy"
        Me.txtAy.Size = New System.Drawing.Size(100, 20)
        Me.txtAy.TabIndex = 2
        '
        'txtAh
        '
        Me.txtAh.Location = New System.Drawing.Point(372, 67)
        Me.txtAh.Name = "txtAh"
        Me.txtAh.Size = New System.Drawing.Size(100, 20)
        Me.txtAh.TabIndex = 5
        '
        'lblAttractive1
        '
        Me.lblAttractive1.AutoSize = True
        Me.lblAttractive1.Location = New System.Drawing.Point(9, 67)
        Me.lblAttractive1.Name = "lblAttractive1"
        Me.lblAttractive1.Size = New System.Drawing.Size(145, 13)
        Me.lblAttractive1.TabIndex = 4
        Me.lblAttractive1.Text = "How Attractive is She? (1-10)"
        '
        'txtEy
        '
        Me.txtEy.Location = New System.Drawing.Point(829, 121)
        Me.txtEy.Name = "txtEy"
        Me.txtEy.Size = New System.Drawing.Size(100, 20)
        Me.txtEy.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(530, 101)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(391, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "How Many Grades Of School Have You Completed? (12=Highschool 16=College)"
        '
        'txtW
        '
        Me.txtW.Location = New System.Drawing.Point(372, 158)
        Me.txtW.Name = "txtW"
        Me.txtW.Size = New System.Drawing.Size(100, 20)
        Me.txtW.TabIndex = 11
        '
        'lblConversation
        '
        Me.lblConversation.AutoSize = True
        Me.lblConversation.Location = New System.Drawing.Point(9, 171)
        Me.lblConversation.Name = "lblConversation"
        Me.lblConversation.Size = New System.Drawing.Size(227, 13)
        Me.lblConversation.TabIndex = 10
        Me.lblConversation.Text = "Are You A Witty Conversationalist? (Rate 1-10)"
        '
        'txtR
        '
        Me.txtR.Location = New System.Drawing.Point(829, 168)
        Me.txtR.Name = "txtR"
        Me.txtR.Size = New System.Drawing.Size(100, 20)
        Me.txtR.TabIndex = 14
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New System.Drawing.Point(530, 168)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(154, 13)
        Me.lblStatus.TabIndex = 13
        Me.lblStatus.Text = "Her Relationship Status? (0-10)"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 217)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(393, 13)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "How Many Things Can You Think Of That You And She Have In Common? (1-10)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(530, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(379, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "How Many Grades of School Has She Completed? (12=Highscool, 16=College)"
        '
        'txtK
        '
        Me.txtK.Location = New System.Drawing.Point(372, 114)
        Me.txtK.Name = "txtK"
        Me.txtK.Size = New System.Drawing.Size(100, 20)
        Me.txtK.TabIndex = 17
        '
        'txtSh
        '
        Me.txtSh.Location = New System.Drawing.Point(829, 260)
        Me.txtSh.Name = "txtSh"
        Me.txtSh.Size = New System.Drawing.Size(100, 20)
        Me.txtSh.TabIndex = 18
        '
        'txtSy
        '
        Me.txtSy.Location = New System.Drawing.Point(829, 214)
        Me.txtSy.Name = "txtSy"
        Me.txtSy.Size = New System.Drawing.Size(100, 20)
        Me.txtSy.TabIndex = 19
        '
        'txtCminus
        '
        Me.txtCminus.Location = New System.Drawing.Point(372, 277)
        Me.txtCminus.Name = "txtCminus"
        Me.txtCminus.Size = New System.Drawing.Size(100, 20)
        Me.txtCminus.TabIndex = 20
        '
        'txtCplus
        '
        Me.txtCplus.Location = New System.Drawing.Point(372, 233)
        Me.txtCplus.Name = "txtCplus"
        Me.txtCplus.Size = New System.Drawing.Size(100, 20)
        Me.txtCplus.TabIndex = 21
        '
        'txtG
        '
        Me.txtG.Location = New System.Drawing.Point(829, 0)
        Me.txtG.Name = "txtG"
        Me.txtG.Size = New System.Drawing.Size(100, 20)
        Me.txtG.TabIndex = 22
        '
        'txtEh
        '
        Me.txtEh.Location = New System.Drawing.Point(829, 64)
        Me.txtEh.Name = "txtEh"
        Me.txtEh.Size = New System.Drawing.Size(100, 20)
        Me.txtEh.TabIndex = 23
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(7, 121)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(228, 13)
        Me.Label5.TabIndex = 25
        Me.Label5.Text = "How Well Does This Person Know You? (1-10)"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(530, 267)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(155, 13)
        Me.Label6.TabIndex = 26
        Me.Label6.Text = "Her Monthly Salary? (In Dollars)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(530, 217)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(160, 13)
        Me.Label7.TabIndex = 27
        Me.Label7.Text = "Your Monthly Salary? (In Dollars)"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(9, 280)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(357, 13)
        Me.Label8.TabIndex = 28
        Me.Label8.Text = "How Many Important Differences Are There Between You And Her? (1-10)"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(530, 7)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(216, 13)
        Me.Label9.TabIndex = 29
        Me.Label9.Text = "How Agressive Are You Willing to be? (1-10)"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(989, 393)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtEh)
        Me.Controls.Add(Me.txtG)
        Me.Controls.Add(Me.txtCplus)
        Me.Controls.Add(Me.txtCminus)
        Me.Controls.Add(Me.txtSy)
        Me.Controls.Add(Me.txtSh)
        Me.Controls.Add(Me.txtK)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtR)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.txtW)
        Me.Controls.Add(Me.lblConversation)
        Me.Controls.Add(Me.txtEy)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtAh)
        Me.Controls.Add(Me.lblAttractive1)
        Me.Controls.Add(Me.txtAy)
        Me.Controls.Add(Me.lblAttractive)
        Me.Controls.Add(Me.btnSubmit)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnSubmit As Button
    Friend WithEvents lblAttractive As Label
    Friend WithEvents txtAy As TextBox
    Friend WithEvents txtAh As TextBox
    Friend WithEvents lblAttractive1 As Label
    Friend WithEvents txtEy As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtW As TextBox
    Friend WithEvents lblConversation As Label
    Friend WithEvents txtR As TextBox
    Friend WithEvents lblStatus As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtK As TextBox
    Friend WithEvents txtSh As TextBox
    Friend WithEvents txtSy As TextBox
    Friend WithEvents txtCminus As TextBox
    Friend WithEvents txtCplus As TextBox
    Friend WithEvents txtG As TextBox
    Friend WithEvents txtEh As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
End Class
